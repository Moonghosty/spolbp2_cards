package br.edu.ifsp.spo.java.cards.nucleo;

import java.util.Scanner;

public class Rodadas {

    }
