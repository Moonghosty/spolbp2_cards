package br.edu.ifsp.spo.java.cards.nucleo;

import br.edu.ifsp.spo.java.cards.itens.Baralho;
import br.edu.ifsp.spo.java.cards.regras.Pontuador;
import br.edu.ifsp.spo.java.cards.ui.JogoUI;

import javax.swing.text.html.Option;
import java.util.Optional;
import java.util.OptionalInt;

public class Jogo {

    private Baralho baralho;
    private Jogador jogador1;
    private Jogador jogador2;
    private Pontuador pontuador;

    private JogoUI ui;

    public Jogo(){
        this.ui = new JogoUI();

        this.pontuador = this.ui.escolherPontuador();
        this.baralho = new Baralho();
        this.jogador1 = new Jogador(ui.solicitarNomeJogador(1));
//        this.jogador2 = new Jogador(ui.solicitarNomeJogador(2));
        this.jogador2 = new JogadorIA();

        for(int i = 0; i < 2; i++){
            this.jogador1.receberCarta(this.baralho.tirarCarta());
            this.jogador2.receberCarta(this.baralho.tirarCarta());
        }
    }

    public void play() {
        int num = ui.NumeroDeRodadas();
        Optional<Jogador> vencedor = rodadas(num);

        if (vencedor.isPresent()) {
            ui.exibirVencedor(vencedor.get());
        } else {
            ui.exibirEmpate();
        }
    }


    private void executarRodada(Jogador jogador) {
        ui.exibirInicioRodada(jogador.getNome());

        AcaoDoJogador acao = AcaoDoJogador.PASSAR;

        do {
            var pontuacao = this.pontuador.verificarPontuacao(jogador.getMao());

            if(jogador instanceof JogadorIA){
                var ia = (JogadorIA) jogador;

                acao = ia.decidir(pontuacao);
            }else{
                ui.exibirMao(jogador.getMao(), pontuacao);

                acao = ui.obterAcao();
            }

            if(acao == AcaoDoJogador.COMPRAR)
                jogador.receberCarta(this.baralho.tirarCarta());

        } while(acao == AcaoDoJogador.COMPRAR);

    }

    private Optional<Jogador> verificarVencedor(int p1, int p2) {
        if (p1 == p2) {
            return Optional.empty();  // Empate
        } else if (p1 > p2) {
            return Optional.of(this.jogador1);
        } else {
            return Optional.of(this.jogador2);
        }
    }


    private void reiniciarRodada() {
        this.baralho.adicionarDescartes(this.jogador1.descartarMao());
        this.baralho.adicionarDescartes(this.jogador2.descartarMao());

        this.jogador1.receberCarta(this.baralho.tirarCarta());
        this.jogador2.receberCarta(this.baralho.tirarCarta());

        this.jogador1.receberCarta(this.baralho.tirarCarta());
        this.jogador2.receberCarta(this.baralho.tirarCarta());
    }

    @Override
    public String toString() {
        String resultado = "Jogo de Baralho Genérico";

        resultado += "\n Jogadores: ";
        resultado += this.jogador1.toString();
        resultado += "\n A pontuação do jogador 1 é: " + this.pontuador.verificarPontuacao(this.jogador1.getMao());
        resultado += this.jogador2.toString();
        resultado += "\n A pontuação do jogador 2 é: " + this.pontuador.verificarPontuacao(this.jogador2.getMao());

        return resultado;
    }
    private Optional<Jogador> rodadas(int numRodadas) {
        int pontosTotaisJogador1 = 0;
        int pontosTotaisJogador2 = 0;

        for (int i = 0; i < numRodadas; i++) {
            ui.exibirNumRodada(i + 1);
            executarRodada(this.jogador1);
            executarRodada(this.jogador2);

            int pontoRodadaJogador1 = pontuador.verificarPontuacao(this.jogador1.getMao());
            int pontoRodadaJogador2 = pontuador.verificarPontuacao(this.jogador2.getMao());
            int[] pontosRodada = calcularPontos(pontoRodadaJogador1, pontoRodadaJogador2);

            pontosTotaisJogador1 += pontosRodada[0];
            pontosTotaisJogador2 += pontosRodada[1];
            reiniciarRodada();
            ui.exibirPontosRodada(pontosTotaisJogador1, this.jogador1.getNome());
            ui.exibirPontosRodada(pontosTotaisJogador2, this.jogador2.getNome());

        }

        return verificarVencedor(pontosTotaisJogador1, pontosTotaisJogador2);
    }

    private int[] calcularPontos(int pontoRodadaJogador1, int pontoRodadaJogador2) {
        int novoPonto1 = 0;
        int novoPonto2 = 0;

        if (pontoRodadaJogador1 > 21 && pontoRodadaJogador2 <= 21) {
            // Jogador 1 estourou, jogador 2 fez menos que 21
            novoPonto1 = -5;
            novoPonto2 = pontoRodadaJogador2;

        } else if (pontoRodadaJogador2 > 21 && pontoRodadaJogador1 <= 21) {
            // Jogador 2 estourou, jogador 1 fez menos que 21
            novoPonto2 = -5;
            novoPonto1 = pontoRodadaJogador1;

        } else if (pontoRodadaJogador1 > 21 && pontoRodadaJogador2 > 21) {
            // Ambos estouraram: perdem a quantidade que ultrapassaram
            novoPonto1 = -(pontoRodadaJogador1 - 21);
            novoPonto2 = -(pontoRodadaJogador2 - 21);

        } else if (pontoRodadaJogador1 == 21 && pontoRodadaJogador2 == 21) {
            // Ambos fizeram 21
            novoPonto1 = 21;
            novoPonto2 = 21;

        } else if (pontoRodadaJogador1 == 21 && pontoRodadaJogador2 != 21) {
            // Jogador 1 fez 21, jogador 2 não
            novoPonto1 = 30;
            novoPonto2 = 0;

        } else if (pontoRodadaJogador2 == 21 && pontoRodadaJogador1 != 21) {
            // Jogador 2 fez 21, jogador 1 não
            novoPonto2 = 30;
            novoPonto1 = 0;

        } else if (pontoRodadaJogador1 < 21 && pontoRodadaJogador2 < 21) {
            // Ambos abaixo de 21: vencedor ganha a diferença
            if (pontoRodadaJogador1 > pontoRodadaJogador2) {
                novoPonto1 = pontoRodadaJogador1 - pontoRodadaJogador2;
                novoPonto2 = 0;
            } else if (pontoRodadaJogador2 > pontoRodadaJogador1) {
                novoPonto2 = pontoRodadaJogador2 - pontoRodadaJogador1;
                novoPonto1 = 0;
            } else {
                // Empate abaixo de 21 → ninguém ganha nada
                novoPonto1 = 10;
                novoPonto2 = 10;
            }
        }

        return new int[]{novoPonto1, novoPonto2};
    }


}
