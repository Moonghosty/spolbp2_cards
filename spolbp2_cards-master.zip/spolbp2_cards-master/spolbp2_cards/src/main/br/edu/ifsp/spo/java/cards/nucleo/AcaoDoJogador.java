package br.edu.ifsp.spo.java.cards.nucleo;

public enum AcaoDoJogador {
    COMPRAR,
    PASSAR
}
